package com.company.Fincard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FincardApplication {

	public static void main(String[] args) {
		SpringApplication.run(FincardApplication.class, args);
		System.out.println("Spring boot application Started");
	}
}
